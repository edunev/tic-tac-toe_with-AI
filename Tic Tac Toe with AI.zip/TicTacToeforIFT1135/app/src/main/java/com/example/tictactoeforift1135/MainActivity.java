/*
UNIVERSITE DE MONTREAL
IFT1135-A-A22  - Introduction aux applications mobiles
Auteur : Eduardo A. Neves  -  matricule : 910436

But du programme : Ce programme implemente une application Android, qui utilisera la classe Jeu,
pour permettre a un utilisateur d’appareil Android de jouer au Tic Tac Toe contre son appareil.

**** Derniere mise a jour: 2022-11-15
*/

package com.example.tictactoeforift1135;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Jeu unJeu = new Jeu();
    private int[] tabGagne = new int[3]; // contient la sequence gagnante
    private boolean fini; //'Vrai' quand le jeu est fini
    Button b; // declaration d'un type Button pour etre utilise dans plusieurs fonctions
    String texteDuBouton;
    int couleurDuBouton;
    TextView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        unJeu.initialise();  // Initialise une partie de TicTacToe   :)

        // Ligne de code pour mettre un icone au choix dans la barra d'actions de l'application
        ActionBar actionBar = getSupportActionBar();
        actionBar.setIcon(android.R.drawable.sym_def_app_icon); // C'est mon icone choisi
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
    }

    // Traiter le choix du joueur 'X'. On verifie si 'X' gagne et on traite le choix de 'O'.
    public void action(Button clicBouton, int choixJoueurX){

        message = findViewById(R.id.statutJeu);

        if (clicBouton.getText() == "X" || clicBouton.getText() == "O" || fini)
            return;
        else {
            clicBouton.setText("X");
            unJeu.setX(choixJoueurX);
        }

        if(unJeu.gagnant("X",tabGagne)){	//Victoire de X?
            fini = true;
            marque(tabGagne); // Marquer en rouge la sequence gagnante (contenue dans tabGane[])

            message.setText(R.string.Xwins);
            } else
            if(!unJeu.isPartieNulle()){				 // Si pas victoire de X et pas nulle
                int choixJoueurO = unJeu.getO();     // Demande le choix pour O (class Jeu)

                // creer un toast avec le choix de 'O'
                String toastChoix_O = "O -> " + choixJoueurO;
                Toast.makeText(this, toastChoix_O, Toast.LENGTH_SHORT).show();

                switch(choixJoueurO){
                    case 0:
                        clicBouton = findViewById(R.id.B1);
                        break;
                    case 1:
                        clicBouton = findViewById(R.id.B2);
                        break;
                    case 2:
                        clicBouton = findViewById(R.id.B3);
                        break;
                    case 3:
                        clicBouton = findViewById(R.id.B4);
                        break;
                    case 4:
                        clicBouton = findViewById(R.id.B5);
                        break;
                    case 5:
                        clicBouton = findViewById(R.id.B6);
                        break;
                    case 6:
                        clicBouton = findViewById(R.id.B7);
                        break;
                    case 7:
                        clicBouton = findViewById(R.id.B8);
                        break;
                    case 8:
                        clicBouton = findViewById(R.id.B9);
                        break;
                }

                clicBouton.setText("O"); // Transmettre le choix de O au bouton correspondant

                if(unJeu.gagnant("O",tabGagne)){	 // O gagne?
                    fini = true;
                    marque(tabGagne); // Marquer en rouge la sequence gagnante (contenue dans tabGane[])
                    message.setText(R.string.Owins);
                }
            }
        else	//Partie nulle
        {
            fini = true;
            message.setText(R.string.draw);
        }
    }


    // Fonctions pour traiter le choix du joueur X quand il tape chaque bouton.
    // Ces fonctions appelent action(Button, int).
    public void clicB1 (View v){ action(findViewById(R.id.B1), 0); };
    public void clicB2 (View v){ action(findViewById(R.id.B2), 1); };
    public void clicB3 (View v){ action(findViewById(R.id.B3), 2); };
    public void clicB4 (View v){ action(findViewById(R.id.B4), 3); };
    public void clicB5 (View v){ action(findViewById(R.id.B5), 4); };
    public void clicB6 (View v){ action(findViewById(R.id.B6), 5); };
    public void clicB7 (View v){ action(findViewById(R.id.B7), 6); };
    public void clicB8 (View v){ action(findViewById(R.id.B8), 7); };
    public void clicB9 (View v){ action(findViewById(R.id.B9), 8); };


    // Marquer en rouge la sequence gagnante (contenue dans tabGane[])
    public void marque (int[] tab){

        for (int i = 0 ; i < tab.length ; i++){
            switch(tab[i]){
                case 0:
                    b = findViewById(R.id.B1);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
                case 1:
                    b = findViewById(R.id.B2);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
                case 2:
                    b = findViewById(R.id.B3);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
                case 3:
                    b = findViewById(R.id.B4);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
                case 4:
                    b = findViewById(R.id.B5);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
                case 5:
                    b = findViewById(R.id.B6);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
                case 6:
                    b = findViewById(R.id.B7);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
                case 7:
                    b = findViewById(R.id.B8);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
                case 8:
                    b = findViewById(R.id.B9);
                    b.setTextColor(Color.parseColor("#FF0000"));
                    break;
            }
        }
    }


    public void reinitialiser (View v){

        // On doit redefinir un 'TextView' pour "statutJeu" pour eviter que l'application plante
        // quand 'Nouvelle partie' est utilisee sans une tentative de jeu prealable.
        // Ex. on demarre l'application et on tape 'Nouvelle partie' tout de suite.


        // Remettre 'TextView' a son etat initial
        TextView reinitialiserMessage = findViewById(R.id.statutJeu);
        reinitialiserMessage.setText("");

        // Remettre les boutons a leurs etat initial
        Button redefinirButton;

        redefinirButton = findViewById(R.id.B1);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

        redefinirButton = findViewById(R.id.B2);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

        redefinirButton = findViewById(R.id.B3);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

        redefinirButton = findViewById(R.id.B4);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

        redefinirButton = findViewById(R.id.B5);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

        redefinirButton = findViewById(R.id.B6);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

        redefinirButton = findViewById(R.id.B7);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

        redefinirButton = findViewById(R.id.B8);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

        redefinirButton = findViewById(R.id.B9);
        redefinirButton.setText ("");
        redefinirButton.setTextColor(Color.parseColor("#000000"));

       fini = false;

       unJeu.initialise();
    }

    @Override
    public void onSaveInstanceState(Bundle  outState) {
        super.onSaveInstanceState(outState);

        outState.putString("statutJeu", ((TextView)findViewById(R.id.statutJeu)).getText().toString());

        outState.putBoolean("fini", fini); // Verifier si le jeu est termine

        // Sauvegarder l'objet courrant "unJeu"
        // cela permet de continuer exactement la meme partie du jeu apres avoir pivoter l'appareil
        outState.putParcelable("jeu", unJeu);

        // Sauvegarder le texte et couleurs des 9 boutons
        b = findViewById(R.id.B1);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B1",texteDuBouton);
        outState.putInt("colorB1", couleurDuBouton);

        b = findViewById(R.id.B2);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B2",texteDuBouton);
        outState.putInt("colorB2", couleurDuBouton);

        b = findViewById(R.id.B3);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B3",texteDuBouton);
        outState.putInt("colorB3", couleurDuBouton);

        b = findViewById(R.id.B4);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B4",texteDuBouton);
        outState.putInt("colorB4", couleurDuBouton);

        b = findViewById(R.id.B5);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B5",texteDuBouton);
        outState.putInt("colorB5", couleurDuBouton);

        b = findViewById(R.id.B6);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B6",texteDuBouton);
        outState.putInt("colorB6", couleurDuBouton);

        b = findViewById(R.id.B7);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B7",texteDuBouton);
        outState.putInt("colorB7", couleurDuBouton);

        b = findViewById(R.id.B8);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B8",texteDuBouton);
        outState.putInt("colorB8", couleurDuBouton);

        b = findViewById(R.id.B9);
        texteDuBouton = b.getText().toString();
        couleurDuBouton = b.getCurrentTextColor();
        outState.putString("B9",texteDuBouton);
        outState.putInt("colorB9", couleurDuBouton);
    }

    @Override
    public void onRestoreInstanceState(Bundle  saveState) {
        super.onRestoreInstanceState( saveState);

        TextView tv = findViewById(R.id.statutJeu);
        tv.setText(saveState.getString("statutJeu"));

        fini = saveState.getBoolean("fini"); // Verifier si le jeu est termine

        // Remetre l'objet "unJeu" em place
        // cela permet de continuer exactement la meme partie du jeu apres avoir pivoter l'appareil
        unJeu = saveState.getParcelable("jeu");

        // Remettre le texte et couleurs des 9 boutons
        texteDuBouton = saveState.getString("B1");
        b = findViewById(R.id.B1);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB1");
        b.setTextColor(couleurDuBouton);

        texteDuBouton = saveState.getString("B2");
        b = findViewById(R.id.B2);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB2");
        b.setTextColor(couleurDuBouton);

        texteDuBouton = saveState.getString("B3");
        b = findViewById(R.id.B3);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB3");
        b.setTextColor(couleurDuBouton);

        texteDuBouton = saveState.getString("B4");
        b = findViewById(R.id.B4);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB4");
        b.setTextColor(couleurDuBouton);

        texteDuBouton = saveState.getString("B5");
        b = findViewById(R.id.B5);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB5");
        b.setTextColor(couleurDuBouton);

        texteDuBouton = saveState.getString("B6");
        b = findViewById(R.id.B6);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB6");
        b.setTextColor(couleurDuBouton);

        texteDuBouton = saveState.getString("B7");
        b = findViewById(R.id.B7);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB7");
        b.setTextColor(couleurDuBouton);

        texteDuBouton = saveState.getString("B8");
        b = findViewById(R.id.B8);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB8");
        b.setTextColor(couleurDuBouton);

        texteDuBouton = saveState.getString("B9");
        b = findViewById(R.id.B9);
        b.setText(texteDuBouton);
        couleurDuBouton = saveState.getInt("colorB9");
        b.setTextColor(couleurDuBouton);
    }
}