package com.example.tictactoeforift1135;
/*
UNIVERSITE DE MONTREAL
IFT1135-A-A22  - Introduction aux applications mobiles
Auteur : Eduardo A. Neves  -  matricule : 910436

But du programme : Ce programme implemente "Parcelable" et define les fonctionnalites necessaires dans MainActivity.java
Il automatise le choix pour le joueur "O". "Parcelable" est utilise pour sauvegarder une instance de la classe et
la rendre disponible apres un changement d'orientation de l'appareil (reinitialisation de l'activite).

**** Derniere mise a jour: 2022-11-15
*/

import android.os.Parcel;
import android.os.Parcelable;



public class Jeu implements Parcelable {

    // Lignes de code pour faire fonctionner "outState.putParcelable("jeu", unJeu);"
    // cela permet de continuer la meme partie du jeu apres avoir pivoter l'appareil
    // Référence : https://developer.android.com/reference/android/os/Parcelable
    private int donneesObj;
    public int describeContents() {
        return 0;
    }

    // sauvegarder l'opbjet dans 'Parcel'
    public void writeToParcel(Parcel out, int flags) {

        out.writeInt(donneesObj);
    }

    public static final Parcelable.Creator<Jeu> CREATOR = new Parcelable.Creator<Jeu>() {
        public Jeu createFromParcel(Parcel in) {

            return new Jeu(in);
        }

        public Jeu[] newArray(int size) {

            return new Jeu[size];
        }
    };

    // remettre l'objet dans 'Parcel'
    private Jeu(Parcel in) {
        donneesObj = in.readInt();
    }

    // L'objet "Jeu" est repere par le code  "unJeu = saveState.getParcelable("jeu");"
    // apres la rotation dans "MainActivity.java"


    private String[] tabGame;

    public Jeu() {
    }

    public void initialise() {

        tabGame = new String[9];

    }

    public void setX(int cellule) {

        tabGame[cellule] = "X";

    }

    private int compterCoups() {
        int coups = 0;

        for (int i = 0; i < tabGame.length; i++)
            if (tabGame[i] != null)
                coups++;

        return coups;

    }

    public int choixJoueurO() {

        int numeroCoup = compterCoups();

        if (numeroCoup == 1) {

            if (tabGame[4] == null)
                return 4;
            else if (tabGame[0] == null)
                return 0;
            else if (tabGame[2] == null)
                return 2;
            else if (tabGame[6] == null)
                return 6;
            else if (tabGame[8] == null)
                return 8;

            return 1;

        }

        if (tabGame[2] == tabGame[5] && tabGame[5] != null) // traiter possibilite particuliere de vitoire de "X"
            if (tabGame[8] ==null && tabGame[4] != "X") {
                //System.out.println ("Test");
                return 8; }

        if (tabGame[2] == tabGame[5] && tabGame[5] != null) // traiter possibilite particuliere de vitoire de "X"
            if (tabGame[8] ==null && tabGame[1] != null ){
                //System.out.println ("Test");
                return 8; }

        if (tabGame[2] == tabGame[8] && tabGame[2] != null) // traiter possibilite particuliere de vitoire de "X"
            if (tabGame[5] == null ){
                //System.out.println ("Test");
                return 5; }

        //System.out.println(numeroCoup);
        if (numeroCoup == 3) {

            /*
             * Deuxième coup S’il ne manque qu’un coup à X pour gagner
             *  alors le bloquer. Ex
             * : X : 0 et 1 et O : 4 donc position 2
             */

            // Essayer de bloquer le joueur "X"
            if (tabGame[0] == "X" && tabGame[2] == "X")
                return 1;

            if (tabGame[3] == "X" && tabGame[5] == "X")
                return 6;

            if (tabGame[6] == "X" && tabGame[8] == "X")
                return 7;

            if (tabGame[0] == "X" && tabGame[1] == "X")
                return 2;

            if (tabGame[3] == "X" && tabGame[4] == "X")
                return 5;

            if (tabGame[6] == "X" && tabGame[7] == "X")
                return 8;

            if (tabGame[1] == "X" && tabGame[2] == "X")
                return 0;

            if (tabGame[4] == "X" && tabGame[5] == "X")
                return 3;

            if (tabGame[7] == "X" && tabGame[8] == "X")
                return 6;

            if (tabGame[3] == "X" && tabGame[6] == "X")
                return 0;

            if (tabGame[4] == "X" && tabGame[7] == "X")
                return 1;

            if (tabGame[5] == "X" && tabGame[8] == "X")
                return 2;

            if (tabGame[1] == "X" && tabGame[7] == "X")
                return 3;

            if (tabGame[0] == "X" && tabGame[3] == "X")
                return 6;

            if (tabGame[2] == "X" && tabGame[5] == "X")
                return 8;

            if (tabGame[2] == "X" && tabGame[4] == "X")
                return 6;

            if (tabGame[6] == "X" && tabGame[4] == "X")
                return 2;

            if (tabGame[2] == "X" && tabGame[8] == "X")
                return 5;

            if (tabGame[0] == "X" && tabGame[6] == "X")
                return 3;

            if (tabGame[1] == "X" && tabGame[4] == "X")
                return 7;

            /*
             *  "X" occupe 2 positions sur une diagonale et O la troisième
             */



            if (       (tabGame[0] == "X" && tabGame[4] == "X" && tabGame[4] == "O")
                    || (tabGame[2] == "X" && tabGame[4] == "X" && tabGame[6] == "O")
                    || (tabGame[6] == "X" && tabGame[4] == "X" && tabGame[2] == "O")
                    || (tabGame[8] == "X" && tabGame[4] == "X" && tabGame[0] == "O")

                    || (tabGame[0] == "X" && tabGame[8] == "X" && tabGame[4] == "O")
                    || (tabGame[2] == "X" && tabGame[6] == "X" && tabGame[4] == "O")       ) {

                /*
                 *  Si O occupe la position 4, alors choisir position 1, 3, 5 ou 7
                 */

                if (tabGame[4] == "O")
                    if (tabGame[1] == null)
                        return 1;
                    else if (tabGame[3] == null)
                        return 3;
                    else if (tabGame[5] == null)
                        return 5;
                    else if (tabGame[7] == null)
                        return 7;

                /*
                 * Sinon, alors choisir un des coins de libre (0, 2, 6 ou 8)
                 */

                if (tabGame[0] == null)
                    return 0;

                if (tabGame[2] == null)
                    return 2;

                if (tabGame[6] == null)
                    return 6;

                if (tabGame[8] == null)
                    return 8;
            }



            // Si O occupe le centre, X occupe un coin et X occupe (1, 3, 5 ou 7), alors
            // choisir le coin le plus près des positions de X.

            if (tabGame[4] == "O" && tabGame[1] == "X")
                if (tabGame[0] == null)
                    return 0;
                else
                    return 2;

            if (tabGame[4] == "O" && tabGame[7] == "X")
                if (tabGame[6] == null)
                    return 6;
                else
                    return 8;

            if (tabGame[4] == "O" && tabGame[5] == "X")
                if (tabGame[6] == null)
                    return 6;
                else
                    return 3;


        }

        // APRES PREMIER ET DEUXIEME COUPS DE "X"
        // Verifie diagonales===================


        if (tabGame[0] == tabGame[4])
            if (tabGame[8] == null)
                return 8;

        if (tabGame[2] == tabGame[4])
            if (tabGame[6] == null)
                return 6;

        if (tabGame[6] == tabGame[4])
            if (tabGame[2] == null)
                return 2;

        if (tabGame[8] == tabGame[4])
            if (tabGame[0] == null)
                return 0;

        // Verifie les colonnes===================

        if (tabGame[3] == tabGame[4]) // traiter possibilite vitoire de "X"
            if (tabGame[5] == null)
                return 5;

        if (tabGame[3] == tabGame[6]) // traiter possibilite vitoire de "X"
            if (tabGame[0] == null)
                return 0;

        if (tabGame[4] == tabGame[5]) // traiter possibilite vitoire de "X"
            if (tabGame[3] == null)
                return 3;

        if (tabGame[3] == tabGame[8]) // traiter possibilite vitoire de "X"
            if (tabGame[6] == null)
                return 6;

        if (tabGame[0] == tabGame[2]) // traiter possibilite vitoire de "X"
            if (tabGame[1] ==null)
                return 1;




        for (int col = 0; col < 3; col++) {

            if ((tabGame[col] == tabGame[col + 3]) && (tabGame[col] != null) && (tabGame[3] != null))
                if (tabGame[col + 6] == null )
                    return col + 6;
        }

        if (tabGame[1] == tabGame[4]) // traiter possibilite vitoire de "X"
            if (tabGame[7] ==null)
                return 7;

        if (tabGame[2] == tabGame[5]) // traiter possibilite vitoire de "X"
            if (tabGame[8] ==null)
                return 8;




        for (int col = 0; col < 3; col++) {

            if ((tabGame[col + 3] == tabGame[col + 6]) && tabGame[col + 3] != null)
                if (tabGame[col + 3] == null)
                    return col + 3;
        }

        for (int col = 0; col < 3; col++) {

            if (tabGame[col] == tabGame[col + 6] && tabGame[col] != null )
                if (tabGame[col + 3] == null)
                    return col + 3;
        }

        // Verifie les lignes=====================
        for (int lin = 0; lin < 9; lin += 3) {

            if (tabGame[lin] == tabGame[lin+1] && tabGame[lin] != null)
                if (tabGame[lin + 2] == null)
                    return lin+2;
        }

        for (int lin = 0; lin < 9; lin += 3 ) {

            if (tabGame[lin] == tabGame[lin + 2] && tabGame[lin] != null)
                if (tabGame[lin + 1] == null)
                    return lin+1;
        }

        for (int lin = 0; lin < 9; lin += 3) {

            if (tabGame[lin + 1] == tabGame[lin + 2] && tabGame[lin+1] != null)
                if (tabGame[lin] == null)
                    return lin;
        }



        // Si le choix n'a pas été traité avant, choisir le premiere case libre.
        for (int i = 0; i < tabGame.length; i++) {
            // System.out.println("LOOP");  // TEMPORAIRE!
            if (tabGame[i] == null)
                return i;
        }

        return -1; // -1 pour detecter un erreur dans la logique de choix plus facilement (index exception). On s'attend de jamais executer cette ligne.
    }

    // Fonction pour ajouter le choix de "O" dans le tableau ET retourner la
    // position (indice 1-8) de ce choix.
    public int getO() {

        int choix = choixJoueurO();

        tabGame[choix] = "O";

        return choix;

    }


    public boolean gagnant(String joueur, int[] pos) {

        // Verifier colonnes=================
        for (int col = 0; col < 3; col++) {

            if ((tabGame[col] == tabGame[col + 3]) && tabGame[col] == tabGame[col + 6])
                if (tabGame[col]  == joueur && tabGame[col] != null) {
                    pos [0] = col; pos [1] = col+3; pos[2]= col+6;
                    return true;
                }
        }

        // Verifier ligne=====================
        for (int lin = 0; lin < 9; lin += 3) {

            if ((tabGame[lin] == tabGame[lin+1]) && (tabGame[lin] == tabGame[lin+2]))
                if (tabGame[lin]  == joueur && tabGame[lin] != null) {
                    pos [0] = lin; pos [1] = lin+1; pos[2]= lin+2;
                    return true;
                }
        }

        // Verifier diagonale==================

        if ( (tabGame[0] == tabGame[4] && tabGame[0] == tabGame[8]) ) {
            if (tabGame[0]  == joueur && tabGame[0] != null) {
                pos [0] = 0; pos [1] = 4; pos[2]= 8;
                return true;
            }

        }


        if ( (tabGame[2] == tabGame[4] && tabGame[2] == tabGame[6]) ) {
            if (tabGame[2]  == joueur && tabGame[2] != null) {
                pos [0] = 2; pos [1] = 4; pos[2]= 6;
                return true;
            }
        }

        //S'il n'y a pas de gagnant
        return false;
    }

    public boolean isPartieNulle() {

        if (compterCoups() == 9)
            return true;
        return false;
    }

    public void testDebug(int[] indicesCoups) {

    }
}
